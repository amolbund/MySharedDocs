import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[appHighLighter]'
})
export class HighLighterDirective {

  @Input() appHighLighter:string ="";

  constructor(private element: ElementRef) {
    
   }

   ngOnInit(){
      //   alert(this.appHighLighter);
      this.element.nativeElement.style.backgroundColor = this.appHighLighter;
   }

}
